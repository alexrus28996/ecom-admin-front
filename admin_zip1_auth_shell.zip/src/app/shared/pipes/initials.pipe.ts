import { Pipe, PipeTransform } from '@angular/core';
@Pipe({ name: 'initials' })
export class InitialsPipe implements PipeTransform {
  transform(name?: string): string {
    if (!name) return '';
    const parts = name.split(' ').filter(Boolean);
    const first = parts[0]?.[0] || '';
    const last = parts.length > 1 ? parts[parts.length-1][0] : '';
    return (first + last).toUpperCase();
  }
}
